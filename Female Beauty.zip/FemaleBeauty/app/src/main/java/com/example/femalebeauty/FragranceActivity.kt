package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class FragranceActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fragrance)

        val btnMoveOil: Button = findViewById(R.id.button_oil)
        btnMoveOil.setOnClickListener(this)
        val btnMoveedp: Button = findViewById(R.id.button_edp)
        btnMoveedp.setOnClickListener(this)
        val btnMoveedt: Button = findViewById(R.id.button_edt)
        btnMoveedt.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)

        val frag1: RelativeLayout = findViewById(R.id.parfume1)
        frag1.setOnClickListener(this)
        val frag2: RelativeLayout = findViewById(R.id.parfume2)
        frag2.setOnClickListener(this)
        val frag3: RelativeLayout = findViewById(R.id.parfume3)
        frag3.setOnClickListener(this)
        val frag4: RelativeLayout = findViewById(R.id.parfume4)
        frag4.setOnClickListener(this)
        val frag5: RelativeLayout = findViewById(R.id.parfume5)
        frag5.setOnClickListener(this)
        val frag6: RelativeLayout = findViewById(R.id.parfume6)
        frag6.setOnClickListener(this)
        val frag7: RelativeLayout = findViewById(R.id.parfume7)
        frag7.setOnClickListener(this)
        val frag8: RelativeLayout = findViewById(R.id.parfume8)
        frag8.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_oil -> {
                val moveoilIntent = Intent(this@FragranceActivity, FragranceActivity::class.java)
                startActivity(moveoilIntent)
            }
            R.id.button_edp -> {
                val moveedpIntent = Intent(this@FragranceActivity, EDPActivity::class.java)
                startActivity(moveedpIntent)
            }
            R.id.button_edt -> {
                val moveedtIntent = Intent(this@FragranceActivity, EDTActivity::class.java)
                startActivity(moveedtIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@FragranceActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.parfume1 -> {
                val frag1 = Intent(this@FragranceActivity, Frag1::class.java)
                startActivity(frag1)
            }
            R.id.parfume2 -> {
                val frag2 = Intent(this@FragranceActivity, Frag2::class.java)
                startActivity(frag2)
            }
            R.id.parfume3 -> {
                val frag3 = Intent(this@FragranceActivity, Frag3::class.java)
                startActivity(frag3)
            }
            R.id.parfume4 -> {
                val frag4 = Intent(this@FragranceActivity, Frag4::class.java)
                startActivity(frag4)
            }
            R.id.parfume5 -> {
                val frag5= Intent(this@FragranceActivity, Frag5::class.java)
                startActivity(frag5)
            }
            R.id.parfume6 -> {
                val frag6= Intent(this@FragranceActivity, Frag6::class.java)
                startActivity(frag6)
            }
            R.id.parfume7 -> {
                val frag7 = Intent(this@FragranceActivity, Frag7::class.java)
                startActivity(frag7)
            }
            R.id.parfume8 -> {
                val frag8 = Intent(this@FragranceActivity, Frag8::class.java)
                startActivity(frag8)
            }
        }
    }
}