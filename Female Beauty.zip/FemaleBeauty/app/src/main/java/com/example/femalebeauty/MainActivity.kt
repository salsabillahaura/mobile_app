package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {

        //hide status bar
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnMoveloglog: Button = findViewById(R.id.button_loglog)
        btnMoveloglog.setOnClickListener(this)

        val btnMovesignup: Button = findViewById(R.id.button_signup)
        btnMovesignup.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.button_loglog -> {
                val moveloglogIntent = Intent(this@MainActivity, LoginActivity::class.java)
                startActivity(moveloglogIntent)
            }
            R.id.button_signup -> {
                val movesignupIntent = Intent(this@MainActivity, SignUpActivity::class.java)
                startActivity(movesignupIntent)
            }
        }
    }
}