package com.example.femalebeauty

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout
import androidx.appcompat.app.AppCompatActivity

class TreatmentActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_treatment)

        val btnMoveTreat: Button = findViewById(R.id.button_treat)
        btnMoveTreat.setOnClickListener(this)
        val btnMoveMoist: Button = findViewById(R.id.button_moist)
        btnMoveMoist.setOnClickListener(this)
        val btnMoveClean: Button = findViewById(R.id.button_cleanser)
        btnMoveClean.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)
        val desclaco1: RelativeLayout = findViewById(R.id.laco1)
        desclaco1.setOnClickListener(this)
        val desclaco2: RelativeLayout = findViewById(R.id.laco2)
        desclaco2.setOnClickListener(this)
        val desclaco3: RelativeLayout = findViewById(R.id.laco3)
        desclaco3.setOnClickListener(this)
        val desclaco4: RelativeLayout = findViewById(R.id.laco4)
        desclaco4.setOnClickListener(this)
        val desclaco5: RelativeLayout = findViewById(R.id.laco5)
        desclaco5.setOnClickListener(this)
        val desclaco6: RelativeLayout = findViewById(R.id.laco6)
        desclaco6.setOnClickListener(this)
        val desclaco7: RelativeLayout = findViewById(R.id.laco7)
        desclaco7.setOnClickListener(this)
        val desclaco8: RelativeLayout = findViewById(R.id.laco8)
        desclaco8.setOnClickListener(this)

    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_moist -> {
                val moveIntent = Intent(this@TreatmentActivity, SkincareActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.button_treat -> {
                val moveTreatmentIntent = Intent(this@TreatmentActivity, TreatmentActivity::class.java)
                startActivity(moveTreatmentIntent)
            }
            R.id.button_cleanser -> {
                val moveCleanserIntent = Intent(this@TreatmentActivity, CleanserActivity::class.java)
                startActivity(moveCleanserIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@TreatmentActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.laco1 -> {
                val desclaco1 = Intent(this@TreatmentActivity, Desclaco1::class.java)
                startActivity(desclaco1)
            }
            R.id.laco2 -> {
                val desclaco2 = Intent(this@TreatmentActivity, Desclaco2::class.java)
                startActivity(desclaco2)
            }
            R.id.laco3 -> {
                val desclaco3 = Intent(this@TreatmentActivity, Desclaco3::class.java)
                startActivity(desclaco3)
            }
            R.id.laco4 -> {
                val desclaco4 = Intent(this@TreatmentActivity, Desclaco4::class.java)
                startActivity(desclaco4)
            }
            R.id.laco5 -> {
                val desclaco5 = Intent(this@TreatmentActivity, Desclaco5::class.java)
                startActivity(desclaco5)
            }
            R.id.laco6 -> {
                val desclaco6 = Intent(this@TreatmentActivity, Desclaco6::class.java)
                startActivity(desclaco6)
            }
            R.id.laco7 -> {
                val desclaco7 = Intent(this@TreatmentActivity, Desclaco7::class.java)
                startActivity(desclaco7)
            }
            R.id.laco8 -> {
                val desclaco8 = Intent(this@TreatmentActivity, Desclaco8::class.java)
                startActivity(desclaco8)
            }
        }
    }
}