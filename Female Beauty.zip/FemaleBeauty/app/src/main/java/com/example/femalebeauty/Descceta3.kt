package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroupOverlay
import android.widget.ImageButton

class Descceta3 : AppCompatActivity(), View. OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_descceta3)

        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.panah -> {
                val movebackIntent = Intent(this@Descceta3, CleanserActivity::class.java)
                startActivity(movebackIntent)
            }
        }
    }
}