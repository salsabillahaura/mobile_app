package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class MoisturActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_moistur)

        val btnMoveMoistur: Button = findViewById(R.id.button_moistur)
        btnMoveMoistur.setOnClickListener(this)
        val btnMoveBath: Button = findViewById(R.id.button_bath_shower)
        btnMoveBath.setOnClickListener(this)
        val btnMovePersonal: Button = findViewById(R.id.button_personal_Care)
        btnMovePersonal.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)

        val descmois1: RelativeLayout = findViewById(R.id.descmois1)
        descmois1.setOnClickListener(this)
        val descmois2: RelativeLayout = findViewById(R.id.descmois2)
        descmois2.setOnClickListener(this)
        val descmois3: RelativeLayout = findViewById(R.id.descmois3)
        descmois3.setOnClickListener(this)
        val descmois4: RelativeLayout = findViewById(R.id.descmois4)
        descmois4.setOnClickListener(this)
        val descmois5: RelativeLayout = findViewById(R.id.descmois5)
        descmois5.setOnClickListener(this)
        val descmois6: RelativeLayout = findViewById(R.id.descmois6)
        descmois6.setOnClickListener(this)
        val descmois7: RelativeLayout = findViewById(R.id.descmois7)
        descmois7.setOnClickListener(this)
        val descmois8: RelativeLayout = findViewById(R.id.descmois8)
        descmois8.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_moistur -> {
                val moveMoisturIntent = Intent(this@MoisturActivity, MoisturActivity::class.java)
                startActivity(moveMoisturIntent)
            }
            R.id.button_bath_shower -> {
                val movebathIntent = Intent(this@MoisturActivity, BodyActivity::class.java)
                startActivity(movebathIntent)
            }
            R.id.button_personal_Care-> {
                val movepersonalIntent = Intent(this@MoisturActivity, PersonalActivity::class.java)
                startActivity(movepersonalIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@MoisturActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.descmois1 -> {
                val descmois1 = Intent(this@MoisturActivity, descmois1::class.java)
                startActivity(descmois1)
            }
            R.id.descmois2 -> {
                val descmois2 = Intent(this@MoisturActivity, Descmois2::class.java)
                startActivity(descmois2)
            }
            R.id.descmois3 -> {
                val descmois3 = Intent(this@MoisturActivity, Descmois3::class.java)
                startActivity(descmois3)
            }
            R.id.descmois4 -> {
                val descmois4 = Intent(this@MoisturActivity, Descmois4::class.java)
                startActivity(descmois4)
            }
            R.id.descmois5 -> {
                val descmois5 = Intent(this@MoisturActivity, Descmois5::class.java)
                startActivity(descmois5)
            }
            R.id.descmois6 -> {
                val descmois6 = Intent(this@MoisturActivity, Descmois6::class.java)
                startActivity(descmois6)
            }
            R.id.descmois7 -> {
                val descmois7 = Intent(this@MoisturActivity, Descmois7::class.java)
                startActivity(descmois7)
            }
            R.id.descmois8 -> {
                val descmois8 = Intent(this@MoisturActivity, Descmois8::class.java)
                startActivity(descmois8)
            }
        }
    }
}