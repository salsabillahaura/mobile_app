package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class PersonalActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_personal)

        val btnMovePersonal: Button = findViewById(R.id.button_personal_Care)
        btnMovePersonal.setOnClickListener(this)
        val btnMoveBath: Button = findViewById(R.id.button_bath_shower)
        btnMoveBath.setOnClickListener(this)
        val btnMoveMoistur: Button = findViewById(R.id.button_moistur)
        btnMoveMoistur.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)
        val descpersonal1: RelativeLayout = findViewById(R.id.descper1)
        descpersonal1.setOnClickListener(this)
        val descper2: RelativeLayout = findViewById(R.id.descper2)
        descper2.setOnClickListener(this)
        val descper3: RelativeLayout = findViewById(R.id.descper3)
        descper3.setOnClickListener(this)
        val descper4: RelativeLayout = findViewById(R.id.descper4)
        descper4.setOnClickListener(this)
        val descper5: RelativeLayout = findViewById(R.id.descper5)
        descper5.setOnClickListener(this)
        val descper6: RelativeLayout = findViewById(R.id.descper6)
        descper6.setOnClickListener(this)
        val descper7: RelativeLayout = findViewById(R.id.descper7)
        descper7.setOnClickListener(this)
        val descper8: RelativeLayout = findViewById(R.id.descper8)
        descper8.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_personal_Care-> {
                val movepersonalIntent = Intent(this@PersonalActivity, PersonalActivity::class.java)
                startActivity(movepersonalIntent)
            }
            R.id.button_bath_shower -> {
                val movebathIntent = Intent(this@PersonalActivity, BodyActivity::class.java)
                startActivity(movebathIntent)
            }
            R.id.button_moistur -> {
                val moveMoisturIntent = Intent(this@PersonalActivity, MoisturActivity::class.java)
                startActivity(moveMoisturIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@PersonalActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.descper1 -> {
                val descper1 = Intent(this@PersonalActivity, descpersonal1::class.java)
                startActivity(descper1)
            }
            R.id.descper2 -> {
                val descper2 = Intent(this@PersonalActivity, Descper2::class.java)
                startActivity(descper2)
            }
            R.id.descper3 -> {
                val descper3 = Intent(this@PersonalActivity, Descper3::class.java)
                startActivity(descper3)
            }
            R.id.descper4 -> {
                val descper4 = Intent(this@PersonalActivity, Descper4::class.java)
                startActivity(descper4)
            }
            R.id.descper5 -> {
                val descper5 = Intent(this@PersonalActivity, Descper5::class.java)
                startActivity(descper5)
            }
            R.id.descper6 -> {
                val descper6 = Intent(this@PersonalActivity, Descper6::class.java)
                startActivity(descper6)
            }
            R.id.descper7 -> {
                val descper7 = Intent(this@PersonalActivity, Descper7::class.java)
                startActivity(descper7)
            }
            R.id.descper8 -> {
                val descper8 = Intent(this@PersonalActivity, Descper8::class.java)
                startActivity(descper8)
            }
        }
    }
}