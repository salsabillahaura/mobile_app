package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class EDPActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_e_d_p)

        val btnMoveedp: Button = findViewById(R.id.button_edp)
        btnMoveedp.setOnClickListener(this)
        val btnMoveOil: Button = findViewById(R.id.button_oil)
        btnMoveOil.setOnClickListener(this)
        val btnMoveedt: Button = findViewById(R.id.button_edt)
        btnMoveedt.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)

        val edp1: RelativeLayout = findViewById(R.id.edp1)
        edp1.setOnClickListener(this)
        val edp2: RelativeLayout = findViewById(R.id.edp2)
        edp2.setOnClickListener(this)
        val edp3: RelativeLayout = findViewById(R.id.edp3)
        edp3.setOnClickListener(this)
        val edp4: RelativeLayout = findViewById(R.id.edp4)
        edp4.setOnClickListener(this)
        val edp5: RelativeLayout = findViewById(R.id.edp5)
        edp5.setOnClickListener(this)
        val edp6: RelativeLayout = findViewById(R.id.edp6)
        edp6.setOnClickListener(this)
        val edp7: RelativeLayout = findViewById(R.id.edp7)
        edp7.setOnClickListener(this)
        val edp8: RelativeLayout = findViewById(R.id.edp8)
        edp8.setOnClickListener(this)
}
    override fun onClick(v: View?) {
    when (v?.id) {
        R.id.button_edp -> {
            val moveedpIntent = Intent(this@EDPActivity, EDPActivity::class.java)
            startActivity(moveedpIntent)
        }
        R.id.button_oil -> {
            val moveoilIntent = Intent(this@EDPActivity, FragranceActivity::class.java)
            startActivity(moveoilIntent)
        }
        R.id.button_edt -> {
            val moveedtIntent = Intent(this@EDPActivity, EDTActivity::class.java)
            startActivity(moveedtIntent)
        }
        R.id.panah -> {
            val movebackIntent = Intent(this@EDPActivity, SkipActivity::class.java)
            startActivity(movebackIntent)
        }
        R.id.edp1 -> {
            val edp1 = Intent(this@EDPActivity, Edp1::class.java)
            startActivity(edp1)
        }
        R.id.edp2 -> {
            val edp2 = Intent(this@EDPActivity, Edp2::class.java)
            startActivity(edp2)
        }
        R.id.edp3 -> {
            val edp3 = Intent(this@EDPActivity, Edp3::class.java)
            startActivity(edp3)
        }
        R.id.edp4 -> {
            val edp4 = Intent(this@EDPActivity, Edp4::class.java)
            startActivity(edp4)
        }
        R.id.edp5 -> {
            val edp5 = Intent(this@EDPActivity, Edp5::class.java)
            startActivity(edp5)
        }
        R.id.edp6 -> {
            val edp6 = Intent(this@EDPActivity, Edp6::class.java)
            startActivity(edp6)
        }
        R.id.edp7 -> {
            val edp7 = Intent(this@EDPActivity, Edp7::class.java)
            startActivity(edp7)
        }
        R.id.edp8 -> {
            val edp8 = Intent(this@EDPActivity, Edp8::class.java)
            startActivity(edp8)
        }
    }
}
}