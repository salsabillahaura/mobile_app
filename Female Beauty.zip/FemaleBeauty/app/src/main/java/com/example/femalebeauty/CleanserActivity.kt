package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class CleanserActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cleanser)

        val btnMoveClean: Button = findViewById(R.id.button_cleanser)
        btnMoveClean.setOnClickListener(this)
        val btnMoveTreat: Button = findViewById(R.id.button_treat)
        btnMoveTreat.setOnClickListener(this)
        val btnMoveMoist: Button = findViewById(R.id.button_moist)
        btnMoveMoist.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)
        val descceta1: RelativeLayout = findViewById(R.id.descceta1)
        descceta1.setOnClickListener(this)
        val descceta2: RelativeLayout = findViewById(R.id.descceta2)
        descceta2.setOnClickListener(this)
        val descceta3: RelativeLayout = findViewById(R.id.descceta3)
        descceta3.setOnClickListener(this)
        val descceta4: RelativeLayout = findViewById(R.id.descceta4)
        descceta4.setOnClickListener(this)
        val descceta5: RelativeLayout = findViewById(R.id.descceta5)
        descceta5.setOnClickListener(this)
        val descceta6: RelativeLayout = findViewById(R.id.descceta6)
        descceta6.setOnClickListener(this)
        val descceta7: RelativeLayout = findViewById(R.id.descceta7)
        descceta7.setOnClickListener(this)
        val descceta8: RelativeLayout = findViewById(R.id.descceta8)
        descceta8.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_cleanser -> {
                val moveCleanserIntent = Intent(this@CleanserActivity, CleanserActivity::class.java)
                startActivity(moveCleanserIntent)
            }
            R.id.button_treat -> {
                val moveTreatmentIntent = Intent(this@CleanserActivity, TreatmentActivity::class.java)
                startActivity(moveTreatmentIntent)
            }
            R.id.button_moist -> {
                val moveIntent = Intent(this@CleanserActivity, SkincareActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@CleanserActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.descceta1 -> {
                val descceta1 = Intent(this@CleanserActivity, Descceta1::class.java)
                startActivity(descceta1)
            }
            R.id.descceta2 -> {
                val descceta2 = Intent(this@CleanserActivity, Descceta2::class.java)
                startActivity(descceta2)
            }
            R.id.descceta3 -> {
                val descceta3 = Intent(this@CleanserActivity, Descceta3::class.java)
                startActivity(descceta3)
            }
            R.id.descceta4 -> {
                val descceta4 = Intent(this@CleanserActivity, Descceta4::class.java)
                startActivity(descceta4)
            }
            R.id.descceta5 -> {
                val descceta5 = Intent(this@CleanserActivity, Descceta5::class.java)
                startActivity(descceta5)
            }
            R.id.descceta6 -> {
                val descceta6 = Intent(this@CleanserActivity, Descceta6::class.java)
                startActivity(descceta6)
            }
            R.id.descceta7 -> {
                val descceta7 = Intent(this@CleanserActivity, Descceta7::class.java)
                startActivity(descceta7)
            }
            R.id.descceta8 -> {
                val descceta8 = Intent(this@CleanserActivity, Descceta8::class.java)
                startActivity(descceta8)
            }
        }
    }
}