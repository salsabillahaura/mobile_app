package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class BodyActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_body)

        val btnMoveBath: Button = findViewById(R.id.button_bath_shower)
        btnMoveBath.setOnClickListener(this)
        val btnMoveMoistur: Button = findViewById(R.id.button_moistur)
        btnMoveMoistur.setOnClickListener(this)
        val btnMovePersonal: Button = findViewById(R.id.button_personal_Care)
        btnMovePersonal.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)

        val descbody1: RelativeLayout = findViewById(R.id.descbody1)
        descbody1.setOnClickListener(this)
        val descbody2: RelativeLayout = findViewById(R.id.descbody2)
        descbody2.setOnClickListener(this)
        val descbody3: RelativeLayout = findViewById(R.id.descbody3)
        descbody3.setOnClickListener(this)
        val descbody4: RelativeLayout = findViewById(R.id.descbody4)
        descbody4.setOnClickListener(this)
        val descbody5: RelativeLayout = findViewById(R.id.descbody5)
        descbody5.setOnClickListener(this)
        val descbody6: RelativeLayout = findViewById(R.id.descbody6)
        descbody6.setOnClickListener(this)
        val descbody7: RelativeLayout = findViewById(R.id.descbody7)
        descbody7.setOnClickListener(this)
        val descbody8: RelativeLayout = findViewById(R.id.descbody8)
        descbody8.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_bath_shower -> {
                val movebathIntent = Intent(this@BodyActivity, BodyActivity::class.java)
                startActivity(movebathIntent)
            }
            R.id.button_moistur -> {
                val moveMoisturIntent = Intent(this@BodyActivity, MoisturActivity::class.java)
                startActivity(moveMoisturIntent)
            }
            R.id.button_personal_Care-> {
                val movepersonalIntent = Intent(this@BodyActivity, PersonalActivity::class.java)
                startActivity(movepersonalIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@BodyActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.descbody1 -> {
                val descbody1 = Intent(this@BodyActivity, descbody1::class.java)
                startActivity(descbody1)
            }
            R.id.descbody2 -> {
                val descbody2 = Intent(this@BodyActivity, Descbody2::class.java)
                startActivity(descbody2)
            }
            R.id.descbody3 -> {
                val descbody3 = Intent(this@BodyActivity, Descbody3::class.java)
                startActivity(descbody3)
            }
            R.id.descbody4 -> {
                val descbody4 = Intent(this@BodyActivity, Descbody4::class.java)
                startActivity(descbody4)
            }
            R.id.descbody5 -> {
                val descbody5 = Intent(this@BodyActivity, Descbody5::class.java)
                startActivity(descbody5)
            }
            R.id.descbody6 -> {
                val descbody6 = Intent(this@BodyActivity, Descbody6::class.java)
                startActivity(descbody6)
            }
            R.id.descbody7 -> {
                val descbody7 = Intent(this@BodyActivity, Descbody7::class.java)
                startActivity(descbody7)
            }
            R.id.descbody8 -> {
                val descbody8 = Intent(this@BodyActivity, Descbody8::class.java)
                startActivity(descbody8)
            }
        }
    }
}