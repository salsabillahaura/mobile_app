package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class FaceActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_face)

        val btnMoveFace: Button = findViewById(R.id.button_face)
        btnMoveFace.setOnClickListener(this)
        val btnMoveLip: Button = findViewById(R.id.button_lips)
        btnMoveLip.setOnClickListener(this)
        val btnMoveCheek: Button = findViewById(R.id.button_cheek)
        btnMoveCheek.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)

        val descfaceface1: RelativeLayout = findViewById(R.id.faceface1)
        descfaceface1.setOnClickListener(this)
        val descfaceface2: RelativeLayout = findViewById(R.id.faceface2)
        descfaceface2.setOnClickListener(this)
        val descfaceface3: RelativeLayout = findViewById(R.id.faceface3)
        descfaceface3.setOnClickListener(this)
        val descfaceface4: RelativeLayout = findViewById(R.id.faceface4)
        descfaceface4.setOnClickListener(this)
        val descfaceface5: RelativeLayout = findViewById(R.id.faceface5)
        descfaceface5.setOnClickListener(this)
        val descfaceface6: RelativeLayout = findViewById(R.id.faceface6)
        descfaceface6.setOnClickListener(this)
        val descfaceface7: RelativeLayout = findViewById(R.id.faceface7)
        descfaceface7.setOnClickListener(this)
        val descfaceface8: RelativeLayout = findViewById(R.id.faceface8)
        descfaceface8.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_face -> {
                val moveFaceIntent = Intent(this@FaceActivity, FaceActivity::class.java)
                startActivity(moveFaceIntent)
            }
            R.id.button_cheek -> {
                val movecheekIntent = Intent(this@FaceActivity, MakeupActivity::class.java)
                startActivity(movecheekIntent)
            }
            R.id.button_lips -> {
                val moveLipsIntent = Intent(this@FaceActivity, LipActivity::class.java)
                startActivity(moveLipsIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@FaceActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.faceface1 -> {
                val descfaceface1 = Intent(this@FaceActivity, Descfaceface1::class.java)
                startActivity(descfaceface1)
            }
            R.id.faceface2 -> {
                val descfaceface2 = Intent(this@FaceActivity, Descfaceface2::class.java)
                startActivity(descfaceface2)
            }
            R.id.faceface3 -> {
                val descfaceface3 = Intent(this@FaceActivity, Descfaceface3::class.java)
                startActivity(descfaceface3)
            }
            R.id.faceface4 -> {
                val descfaceface4 = Intent(this@FaceActivity, Descfaceface4::class.java)
                startActivity(descfaceface4)
            }
            R.id.faceface5 -> {
                val descfaceface5 = Intent(this@FaceActivity, Descfaceface5::class.java)
                startActivity(descfaceface5)
            }
            R.id.faceface6 -> {
                val descfaceface6 = Intent(this@FaceActivity, Descfaceface6::class.java)
                startActivity(descfaceface6)
            }
            R.id.faceface7 -> {
                val descfaceface7 = Intent(this@FaceActivity, Descfaceface7::class.java)
                startActivity(descfaceface7)
            }
            R.id.faceface8 -> {
                val descfaceface8 = Intent(this@FaceActivity, Descfaceface8::class.java)
                startActivity(descfaceface8)
            }
        }
    }
}