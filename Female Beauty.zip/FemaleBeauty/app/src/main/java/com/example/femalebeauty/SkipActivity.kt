package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.ActionBar

class SkipActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skip)

        if (supportActionBar != null) {
            (supportActionBar as ActionBar).title = "Skincare"
        }

        val btnMoveSkin: Button = findViewById(R.id.skin_care)
        btnMoveSkin.setOnClickListener(this)
        val btnMoveMakeup: Button = findViewById(R.id.make_up)
        btnMoveMakeup.setOnClickListener(this)
        val btnMoveBody: Button = findViewById(R.id.body)
        btnMoveBody.setOnClickListener(this)
        val btnMoveFragrance: Button = findViewById(R.id.fragrance)
        btnMoveFragrance.setOnClickListener(this)
        val btnMoveabout: ImageButton = findViewById(R.id.aboutus)
        btnMoveabout.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.skin_care -> {
                val moveIntent = Intent(this@SkipActivity, SkincareActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.make_up -> {
                val moveMakeupIntent = Intent(this@SkipActivity, MakeupActivity::class.java)
                startActivity(moveMakeupIntent)
            }
            R.id.body-> {
                val moveBodyIntent = Intent(this@SkipActivity, BodyActivity::class.java)
                startActivity(moveBodyIntent)
            }
            R.id.fragrance-> {
                val moveFragranceIntent = Intent(this@SkipActivity, FragranceActivity::class.java)
                startActivity(moveFragranceIntent)
            }
            R.id.aboutus-> {
                val moveabout = Intent(this@SkipActivity, aboutus::class.java)
                startActivity(moveabout)
            }
        }
    }
}