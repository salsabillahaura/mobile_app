package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class EDTActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_e_d_t)

        val btnMoveedt: Button = findViewById(R.id.button_edt)
        btnMoveedt.setOnClickListener(this)
        val btnMoveedp: Button = findViewById(R.id.button_edp)
        btnMoveedp.setOnClickListener(this)
        val btnMoveOil: Button = findViewById(R.id.button_oil)
        btnMoveOil.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)

        val descedt1: RelativeLayout = findViewById(R.id.perfume_edt1)
        descedt1.setOnClickListener(this)
        val descedt2: RelativeLayout = findViewById(R.id.perfume_edt2)
        descedt2.setOnClickListener(this)
        val descedt3: RelativeLayout = findViewById(R.id.perfume_edt3)
        descedt3.setOnClickListener(this)
        val descedt4: RelativeLayout = findViewById(R.id.perfume_edt4)
        descedt4.setOnClickListener(this)
        val descedt5: RelativeLayout = findViewById(R.id.perfume_edt5)
        descedt5.setOnClickListener(this)
        val descedt6: RelativeLayout = findViewById(R.id.perfume_edt6)
        descedt6.setOnClickListener(this)
        val descedt7: RelativeLayout = findViewById(R.id.perfume_edt7)
        descedt7.setOnClickListener(this)
        val descedt8: RelativeLayout = findViewById(R.id.perfume_edt8)
        descedt8.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_edt -> {
                val moveedtIntent = Intent(this@EDTActivity, EDTActivity::class.java)
                startActivity(moveedtIntent)
            }
            R.id.button_edp -> {
                val moveedpIntent = Intent(this@EDTActivity, EDPActivity::class.java)
                startActivity(moveedpIntent)
            }
            R.id.button_oil -> {
                val moveoilIntent = Intent(this@EDTActivity, FragranceActivity::class.java)
                startActivity(moveoilIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@EDTActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.perfume_edt1 -> {
                val descedt1 = Intent(this@EDTActivity, Descedt1::class.java)
                startActivity(descedt1)
            }
            R.id.perfume_edt2 -> {
                val descedt2 = Intent(this@EDTActivity, Descedt2::class.java)
                startActivity(descedt2)
            }
            R.id.perfume_edt3 -> {
                val descedt3 = Intent(this@EDTActivity, Descedt3::class.java)
                startActivity(descedt3)
            }
            R.id.perfume_edt4 -> {
                val descedt4 = Intent(this@EDTActivity, Descedt4::class.java)
                startActivity(descedt4)
            }
            R.id.perfume_edt5 -> {
                val descedt5 = Intent(this@EDTActivity, Descedt5::class.java)
                startActivity(descedt5)
            }
            R.id.perfume_edt6 -> {
                val descedt6 = Intent(this@EDTActivity, Descedt6::class.java)
                startActivity(descedt6)
            }
            R.id.perfume_edt7 -> {
                val descedt7 = Intent(this@EDTActivity, Descedt7::class.java)
                startActivity(descedt7)
            }
            R.id.perfume_edt8 -> {
                val descedt8 = Intent(this@EDTActivity, Descedt8::class.java)
                startActivity(descedt8)
            }
        }
    }
}