package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.lang.NumberFormatException

class LoginActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var edtlogin: EditText
    private lateinit var edtpw: EditText
    private lateinit var buttonlog: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        edtlogin = findViewById(R.id.edt_login)
        edtpw = findViewById(R.id.edt_pwd)
        buttonlog = findViewById(R.id.button_logloglog)

        val buttonlog: Button = findViewById(R.id.button_logloglog)
        buttonlog.setOnClickListener(this)

    }
    override fun onClick(v: View?) {
        val inputlogin = edtlogin.text.toString().trim()
        val inputpw = edtpw.text.toString().trim()

        var isEmptyFields = false

        if (inputlogin.isEmpty()) {
            isEmptyFields = true
            edtlogin.error = "Field ini tidak boleh kosong"
            return
        }
        else if (inputpw.isEmpty()) {
            isEmptyFields = true
            edtpw.error = "Field ini tidak boleh kosong"
            return
        }
        when (v?.id) {
            R.id.button_logloglog -> {
                val movelogloglogIntent = Intent(this@LoginActivity, SkipActivity::class.java)
                startActivity(movelogloglogIntent)
            }
        }
    }
}