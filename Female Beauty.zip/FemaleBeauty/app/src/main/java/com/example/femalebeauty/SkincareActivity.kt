package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class SkincareActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skincare)

        val btnMoveMoist: Button = findViewById(R.id.button_moist)
        btnMoveMoist.setOnClickListener(this)
        val btnMoveTreat: Button = findViewById(R.id.button_treat)
        btnMoveTreat.setOnClickListener(this)
        val btnMoveClean: Button = findViewById(R.id.button_cleanser)
        btnMoveClean.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)
        val deschada1: RelativeLayout = findViewById(R.id.hada1)
        deschada1.setOnClickListener(this)
        val deschada2: RelativeLayout = findViewById(R.id.hada2)
        deschada2.setOnClickListener(this)
        val deschada3: RelativeLayout = findViewById(R.id.hada3)
        deschada3.setOnClickListener(this)
        val deschada4: RelativeLayout = findViewById(R.id.hada4)
        deschada4.setOnClickListener(this)
        val deschada5: RelativeLayout = findViewById(R.id.hada5)
        deschada5.setOnClickListener(this)
        val deschada6: RelativeLayout = findViewById(R.id.hada6)
        deschada6.setOnClickListener(this)
        val deschada7: RelativeLayout = findViewById(R.id.hada7)
        deschada7.setOnClickListener(this)
        val deschada8: RelativeLayout = findViewById(R.id.hada8)
        deschada8.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_moist -> {
                val moveIntent = Intent(this@SkincareActivity, SkincareActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.button_treat -> {
                val moveTreatmentIntent = Intent(this@SkincareActivity, TreatmentActivity::class.java)
                startActivity(moveTreatmentIntent)
            }
            R.id.button_cleanser -> {
                val moveCleanserIntent = Intent(this@SkincareActivity, CleanserActivity::class.java)
                startActivity(moveCleanserIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@SkincareActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.hada1 -> {
                val deschada1 = Intent(this@SkincareActivity, Deschada1::class.java)
                startActivity(deschada1)
            }
            R.id.hada2 -> {
                val deschada2 = Intent(this@SkincareActivity, Deschada2::class.java)
                startActivity(deschada2)
            }
            R.id.hada3 -> {
                val deschada3 = Intent(this@SkincareActivity, Deschada3::class.java)
                startActivity(deschada3)
            }
            R.id.hada4 -> {
                val deschada4 = Intent(this@SkincareActivity, Deschada4::class.java)
                startActivity(deschada4)
            }
            R.id.hada5 -> {
                val deschada5= Intent(this@SkincareActivity, Deschada5::class.java)
                startActivity(deschada5)
            }
            R.id.hada6 -> {
                val deschada6= Intent(this@SkincareActivity, Deschada6::class.java)
                startActivity(deschada6)
            }
            R.id.hada7 -> {
                val deschada7 = Intent(this@SkincareActivity, Deschada7::class.java)
                startActivity(deschada7)
            }
            R.id.hada8 -> {
                val deschada8 = Intent(this@SkincareActivity, Deschada8::class.java)
                startActivity(deschada8)
            }
        }
    }
}