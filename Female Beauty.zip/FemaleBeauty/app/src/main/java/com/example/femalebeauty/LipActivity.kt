package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class LipActivity : AppCompatActivity(), View.OnClickListener  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lip)

        val btnMoveLip: Button = findViewById(R.id.button_lips)
        btnMoveLip.setOnClickListener(this)
        val btnMoveCheek: Button = findViewById(R.id.button_cheek)
        btnMoveCheek.setOnClickListener(this)
        val btnMoveFace: Button = findViewById(R.id.button_face)
        btnMoveFace.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)

        val desclip1: RelativeLayout = findViewById(R.id.liplip1)
        desclip1.setOnClickListener(this)
        val desclip2: RelativeLayout = findViewById(R.id.liplip2)
        desclip2.setOnClickListener(this)
        val desclip3: RelativeLayout = findViewById(R.id.liplip3)
        desclip3.setOnClickListener(this)
        val desclip4: RelativeLayout = findViewById(R.id.liplip4)
        desclip4.setOnClickListener(this)
        val desclip5: RelativeLayout = findViewById(R.id.liplip5)
        desclip5.setOnClickListener(this)
        val desclip6: RelativeLayout = findViewById(R.id.liplip6)
        desclip6.setOnClickListener(this)
        val desclip7: RelativeLayout = findViewById(R.id.liplip7)
        desclip7.setOnClickListener(this)
        val desclip8: RelativeLayout = findViewById(R.id.liplip8)
        desclip8.setOnClickListener(this)

    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_cheek -> {
                val movecheekIntent = Intent(this@LipActivity, MakeupActivity::class.java)
                startActivity(movecheekIntent)
            }
            R.id.button_lips -> {
                val moveLipsIntent = Intent(this@LipActivity, LipActivity::class.java)
                startActivity(moveLipsIntent)
            }
            R.id.button_face -> {
                val moveFaceIntent = Intent(this@LipActivity, FaceActivity::class.java)
                startActivity(moveFaceIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@LipActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.liplip1 -> {
                val desclip1 = Intent(this@LipActivity, Desclip1::class.java)
                startActivity(desclip1)
            }
            R.id.liplip2 -> {
                val desclip2 = Intent(this@LipActivity, Desclip2::class.java)
                startActivity(desclip2)
            }
            R.id.liplip3 -> {
                val desclip3 = Intent(this@LipActivity, Desclip3::class.java)
                startActivity(desclip3)
            }
            R.id.liplip4 -> {
                val desclip4 = Intent(this@LipActivity, Desclip4::class.java)
                startActivity(desclip4)
            }
            R.id.liplip5 -> {
                val desclip5 = Intent(this@LipActivity, Desclip5::class.java)
                startActivity(desclip5)
            }
            R.id.liplip6 -> {
                val desclip6 = Intent(this@LipActivity, Desclip6::class.java)
                startActivity(desclip6)
            }
            R.id.liplip7 -> {
                val desclip7 = Intent(this@LipActivity, Desclip7::class.java)
                startActivity(desclip7)
            }
            R.id.liplip8 -> {
                val desclip8 = Intent(this@LipActivity, Desclip8::class.java)
                startActivity(desclip8)
            }
        }
    }
}