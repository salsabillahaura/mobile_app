package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.RelativeLayout

class MakeupActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_makeup)

        val btnMoveCheek: Button = findViewById(R.id.button_cheek)
        btnMoveCheek.setOnClickListener(this)
        val btnMoveLip: Button = findViewById(R.id.button_lips)
        btnMoveLip.setOnClickListener(this)
        val btnMoveFace: Button = findViewById(R.id.button_face)
        btnMoveFace.setOnClickListener(this)
        val btnmovebackIntent: ImageButton = findViewById(R.id.panah)
        btnmovebackIntent.setOnClickListener(this)

        val descmakeover1: RelativeLayout = findViewById(R.id.makeover1)
        descmakeover1.setOnClickListener(this)
        val descmakeover2: RelativeLayout = findViewById(R.id.makeover2)
        descmakeover2.setOnClickListener(this)
        val descmakeover3: RelativeLayout = findViewById(R.id.makeover3)
        descmakeover3.setOnClickListener(this)
        val descmakeover4: RelativeLayout = findViewById(R.id.makeover4)
        descmakeover4.setOnClickListener(this)
        val descmakeover5: RelativeLayout = findViewById(R.id.makeover5)
        descmakeover5.setOnClickListener(this)
        val descmakeover6: RelativeLayout = findViewById(R.id.makeover6)
        descmakeover6.setOnClickListener(this)
        val descmakeover7: RelativeLayout = findViewById(R.id.makeover7)
        descmakeover7.setOnClickListener(this)
        val descmakeover8: RelativeLayout = findViewById(R.id.makeover8)
        descmakeover8.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.button_cheek -> {
                val movecheekIntent = Intent(this@MakeupActivity, MakeupActivity::class.java)
                startActivity(movecheekIntent)
            }
            R.id.button_lips -> {
                val moveLipsIntent = Intent(this@MakeupActivity, LipActivity::class.java)
                startActivity(moveLipsIntent)
            }
            R.id.button_face -> {
                val moveFaceIntent = Intent(this@MakeupActivity, FaceActivity::class.java)
                startActivity(moveFaceIntent)
            }
            R.id.panah -> {
                val movebackIntent = Intent(this@MakeupActivity, SkipActivity::class.java)
                startActivity(movebackIntent)
            }
            R.id.makeover1 -> {
                val descmakeover1 = Intent(this@MakeupActivity, Descmakeover1::class.java)
                startActivity(descmakeover1)
            }
            R.id.makeover2 -> {
                val descmakeover2 = Intent(this@MakeupActivity, Descmakeover2::class.java)
                startActivity(descmakeover2)
            }
            R.id.makeover3 -> {
                val descmakeover3 = Intent(this@MakeupActivity, Descmakeover3::class.java)
                startActivity(descmakeover3)
            }
            R.id.makeover4 -> {
                val descmakeover4 = Intent(this@MakeupActivity, Descmakeover4::class.java)
                startActivity(descmakeover4)
            }
            R.id.makeover5 -> {
                val descmakeover5 = Intent(this@MakeupActivity, Descmakeover5::class.java)
                startActivity(descmakeover5)
            }
            R.id.makeover6 -> {
                val descmakeover6 = Intent(this@MakeupActivity, Descmakeover6::class.java)
                startActivity(descmakeover6)
            }
            R.id.makeover7 -> {
                val descmakeover7 = Intent(this@MakeupActivity, Descmakeover7::class.java)
                startActivity(descmakeover7)
            }
            R.id.makeover8 -> {
                val descmakeover8 = Intent(this@MakeupActivity, Descmakeover8::class.java)
                startActivity(descmakeover8)
            }
        }
    }
}