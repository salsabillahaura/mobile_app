package com.example.femalebeauty

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class SignUpActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var edtphone: EditText
    private lateinit var edtuser: EditText
    private lateinit var edtpass: EditText
    private lateinit var btnMoveloglogloglog: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        edtphone = findViewById(R.id.phone)
        edtuser = findViewById(R.id.user)
        edtpass = findViewById(R.id.pass)
        btnMoveloglogloglog = findViewById(R.id.button_loglogloglog)

        val btnMoveloglogloglog : Button = findViewById(R.id.button_loglogloglog)
        btnMoveloglogloglog.setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        val inputphone = edtphone.text.toString().trim()
        val inputuser = edtuser.text.toString().trim()
        val inputpass = edtpass.text.toString().trim()

        var isEmptyFields = false
        if (inputphone.isEmpty()) {
            isEmptyFields = true
            edtphone.error = "Field ini tidak boleh kosong"
            return
        }
        if (inputuser.isEmpty()) {
            isEmptyFields = true
            edtuser.error = "Field ini tidak boleh kosong"
            return

        }
        if (inputpass.isEmpty()) {
            isEmptyFields = true
            edtpass.error = "Field ini tidak boleh kosong"
            return

        }
        when (v?.id) {
            R.id.button_loglogloglog -> {
                val moveloglogloglogIntent = Intent(this@SignUpActivity, SkipActivity::class.java)
                startActivity(moveloglogloglogIntent)
            }
        }
    }
}